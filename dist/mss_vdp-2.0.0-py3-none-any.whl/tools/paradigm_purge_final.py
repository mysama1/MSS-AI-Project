"""Final purge for deeply nested residuals"""
import re

fixes = [
    (r"C:\MSS-AI-Project\knowledge_base\scaling_law_critique_v1.0.jsonl", [
        ("单次训练的热税", "单次统计拟合的热税"),
    ]),
    (r"C:\MSS-AI-Project\MSS_理论体系完整归档_v15.1.md", [
        ("梯度下降训练", "梯度下降统计拟合"),
        ("训练时间", "统计拟合时间"),
        ("逻辑刚性训练", "逻辑刚性调谐"),
    ]),
    (r"C:\MSS-AI-Project\knowledge_base_organized\L2_保护带.md", [
        ("逻辑刚性训练", "逻辑刚性调谐"),
    ]),
]

for fp, pairs in fixes:
    with open(fp, 'r', encoding='utf-8') as f:
        c = f.read()
    before = c.count("训练")
    for old, new in pairs:
        c = c.replace(old, new)
    after = c.count("训练")
    if before != after:
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(c)
        name = fp.split('\\')[-1]
        print(f"OK {name}: {before} -> {after}")
    else:
        print(f"SKIP {fp.split(chr(92))[-1]}")

print("Done.")