import json, datetime

entry = {
    "id": "H147",
    "layer": "L2",
    "category": "protective_belt",
    "title": "身份焦虑热税的时间复合模型",
    "subtitle": "精卵捐赠匿名制度的社会热税演化",
    "content": (
        "热税时间复合公式: gamma_total(t) = gamma_0*(1+r)^t "
        "可验证预测：任何引入匿名身份切割的制度，热税20-30年后达显化峰值。"
        "制度补丁链：每次修补支付新一轮gamma，K4方向不修补旧契约而重新锚定身份基础。"
        "信任代理热税杠杆攻击: gamma_total=k*N*gamma_0 (k远大于1为信任系数)。"
        "寻亲节目=L3热税释放阀（止痛药模式）。身份焦虑从个人心理升级为文明级热税危机。"
        "实证锚点：美2470万无父儿童(rho_rupture=0.33)，30年寻亲秀，2025-26纪录片井喷(第一代匿名后代成年触发)。"
        "K4升维方向：身份=养育的逻辑功W_logic而非配子贡献。"
    ),
    "confidence": 0.92,
    "axiom_refs": ["A1", "A2", "A3", "A5", "A6"],
    "falsifiability": "若寻亲热潮未在首批匿名后代成年后20-30年出现，则热税复合假设需修正",
    "created_at": datetime.datetime.now().isoformat(),
}

fp = r"C:\MSS-AI-Project\knowledge_base\h147_identity_heat_tax_model_v1.0.jsonl"
with open(fp, "w", encoding="utf-8") as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")

print("H147 archived OK")
print("axioms:", entry["axiom_refs"])