"""Final residual purge for deeply nested compound terms"""
import re

# These two large files share the same residual patterns
FILES = [
    r"C:\MSS-AI-Project\MSS_理论体系完整归档_v15.1.md",
    r"C:\MSS-AI-Project\knowledge_base_organized\L2_保护带.md",
    r"C:\MSS-AI-Project\knowledge_base\scaling_law_critique_v1.0.jsonl",
]

REPLACE = [
    ("训练策略改进", "调谐策略改进"),
    ("专注力训练", "专注力调谐"),
    ("相似度训练", "相似度调谐"),
    ("超出训练分布", "超出统计拟合分布"),
    ("PPO训练", "PPO统计拟合"),
    ("RLHF训练后", "RLHF统计拟合后"),
    ("对齐训练", "对齐调谐"),
    ("单次训练", "单次统计拟合"),
    ("训练时间越长", "统计拟合时间越长"),
]

for fp in FILES:
    with open(fp, 'r', encoding='utf-8') as f:
        c = f.read()
    before = c.count("训练")
    for old, new in REPLACE:
        c = c.replace(old, new)
    after = c.count("训练")
    if before != after:
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(c)
    name = fp.split('\\')[-1]
    print(f"{name}: {before} -> {after}")

print("Done.")